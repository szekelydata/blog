<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Eighties
 * @author Justin Kopepasah
 * @since 1.0.0
 */
?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<?php get_sidebar( 'footer' ); ?>

		<div class="site-info">
			<a href="http://www.transindex.ro"><img src="<?php echo get_stylesheet_directory_uri() . '/images/transindex-logo.png' ?>" style="background: #FFF; padding: 7px;height: 62px; vertical-align: middle;margin: 20px;" /></a>
			<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'eighties' ) ); ?>"><?php printf( __( 'Built with %s', 'eighties' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( __( 'Themex: %1$s by %2$s.', 'eighties' ), '<a href="' . esc_url( "http://eighties.me/" ) . '" rel="designer">Eighties</a>', '<a href="' . esc_url( "http://kopepasah.com/" ) . '" rel="designer">Kopepasah</a>' ); ?>
			<div style="display: inline-block; vertical-align: middle; margin: 20px; height: 38px">
				<script>t_rid="transindexro";</script>
				<script src="http://storage.trafic.ro/js/trafic.js"></script>

				<noscript><a href="http://www.trafic.ro/top/?rid=transindexro">
				<img src="http://log.trafic.ro/cgi-bin/pl.dll?rid=transindexro"
				 border=0 alt="trafic ranking"></a></noscript>
			</div>	
			<script>
				(function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
				function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
				e=o.createElement(i);r=o.getElementsByTagName(i)[0];
				e.src='//www.google-analytics.com/analytics.js';
				r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
				ga('create','UA-2170139-7');ga('send','pageview');
			</script>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
